
'''
Python Fundementals Workshop 5
Kenny Hin 
July 30, 2022
'''
import random


def guess_random_num(tries, start, stop):
    '''
    guess_random_num doc string
    '''
    random_number = random.randint(start, stop)
    guessed = []

    while tries != 0:

        print(f"Remaining tries: {tries}")
        print("the answer is", random_number)
        user_guess = int(input("Guess a number: "))
        print(f"Guessed: {guessed}")
        for num in guessed:
            if user_guess == num:
                print("Number already guessed,try again")
                tries += 1
                break

        guessed.append(user_guess)
        if user_guess == random_number:
            print("You got it! Good Job")
            return user_guess
        if user_guess < random_number:
            tries -= 1
            print("Guess higher")
        if user_guess > random_number:
            tries -= 1
            print("Guess Lower")
        if tries == 0:
            print(f"You failed to guess the number: {random_number}")
            break


def guess_random_num_linear(tries, start, stop):
    '''
    guess_random_num_linear doc string
    '''
    random_number = random.randint(start, stop)
    print(f"The secret number is: {random_number}")
    for num in range(start, stop):
        print(f"Number of tries left: {tries}")
        print(f"The program is guessing.... {num}")
        if tries == 0:
            print("The program could not guess the correct number")
            return False
        if num == random_number:
            print("The program guessed the number!! ")
            return True
        if num > random_number or num < random_number:
            tries -= 1


def guess_random_num_binary(tries, start, stop):
    '''
    guess_random_num_binary doc string
    '''
    random_number = random.randint(start, stop)

    lower_bound = start
    upper_bound = stop

    while True:
        print(f"Random number to find {random_number} ")
        print(f"Number of tries: {tries}")
        pivot = (lower_bound + upper_bound) // 2
        if pivot == random_number:
            print("Program guessed it")
            return True
        if pivot > random_number:
            upper_bound = pivot - 1
            tries -= 1
            print("Guessing lower")
        if pivot < random_number:
            lower_bound = pivot + 1
            tries -= 1
            print("Guessing Higher")
        if tries == 0:
            print("Program could not guess it")
            break


def users_choice():
    '''
    user choice function
    '''
    tries = int(input("Enter amount of tries: "))
    start = int(input("Enter start value: "))
    stop = int(input("Enter stop value: "))
    method = input("Choose your method: 1)Brute 2)Linear 3)Binary ::  ")
    if method == "1":
        guess_random_num(tries, start, stop)
    if method == "2":
        guess_random_num_linear(tries, start, stop)
    if method == "3":
        guess_random_num_binary(tries, start, stop)

# Add bonus task 1 - 3 here


def gambling_game():  # bonus task 4
    '''this is for bonus task 4 - make a game where you bet if the computer
    will win or not using the function from task two guess_random_num_linear(...).
    '''
    player_bank = 10
    print(f"Bank: ${player_bank}")
    while player_bank != 0:
        bet_question = input("Will computer guess the correct number? Y/N: ")
        while True:
            bet_amt = int(input("How much would you like to bet? $"))
            if bet_amt <= player_bank:
                break
            else:
                print("You don't have enough in the bank")

        outcome = guess_random_num_linear(5, 0, 10)
        if outcome is True and bet_question == "Y":
            player_bank += bet_amt
        if outcome is False and bet_question == "N":
            player_bank += bet_amt
        if outcome is True and bet_question == "N":
            player_bank -= bet_amt
        if outcome is False and bet_question == "Y":
            player_bank -= bet_amt
        if player_bank == 50:
            print("You win!")
            break
        print(f"Bank: ${player_bank}")
    print("You lose")

    # Driver Code Task One
    #   5 == tries
    #   0, 10 == Range of random integers to choose from.


    # guess_random_num(5, 0, 10)
    # Driver Code Task Two
    #   5 == tries
    #   0, 10 == Range of random integers to choose from.
    # guess_random_num_linear(5, 0, 10)
    # Driver Code Task Three
    #   5 == tries
    #   0, 100 == Range of random integers to choose from.
    # guess_random_num_binary(5, 0, 100)
    # users_choice()
    # Driver code for gambling game
gambling_game()
